package com.example.littlelemon.ui.theme

object LittleLemonColor {
}
