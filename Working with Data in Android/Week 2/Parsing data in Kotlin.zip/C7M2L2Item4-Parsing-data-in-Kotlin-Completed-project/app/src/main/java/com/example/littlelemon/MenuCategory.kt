package com.example.littlelemon

import kotlinx.serialization.Serializable

@Serializable
class MenuCategory(
    val menu: List<String>
)
